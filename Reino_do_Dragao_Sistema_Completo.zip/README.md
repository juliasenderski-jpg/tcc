# 🐉 Reino do Dragão — Sistema de Reservas

Sistema local de reservas para o restaurante Reino do Dragão, inspirado em plataformas de gestão de agenda, mas personalizado para o restaurante.

## Recursos

- Página pública para clientes fazerem reservas.
- Painel do restaurante.
- Dashboard com indicadores.
- Lista, busca e filtros de reservas.
- Calendário por dia.
- Alteração de status.
- Código único de reserva.
- Consulta da reserva pelo cliente.
- Banco de dados SQLite criado automaticamente.
- Limite de 30 pessoas por reserva.
- Limite de 48 pessoas reserváveis por dia (40% de 120).
- Horários a partir das 19h.
- Regra de cancelamento de 48 horas.

## Como executar

1. Instale o Node.js.
2. Abra esta pasta no VS Code.
3. Abra o terminal.
4. Execute:

```bash
npm install
npm start
```

5. Acesse:

http://localhost:3000

Painel do restaurante:

http://localhost:3000/admin.html

O arquivo `reino-dragao.db` será criado automaticamente na primeira execução.

## Observação

Este projeto é uma base escolar/local. Para colocar o sistema em produção, ainda seria necessário adicionar autenticação do painel, proteção de API, HTTPS, backup e configuração de servidor/banco apropriada.
