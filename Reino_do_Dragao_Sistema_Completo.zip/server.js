const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = 3000;
const db = new Database("reino-dragao.db");

db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS reservas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo TEXT NOT NULL UNIQUE,
  nome TEXT NOT NULL,
  telefone TEXT NOT NULL,
  email TEXT NOT NULL,
  data TEXT NOT NULL,
  horario TEXT NOT NULL,
  pessoas INTEGER NOT NULL,
  observacoes TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Pendente',
  criado_em TEXT NOT NULL
);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function codigoReserva() {
  let codigo;
  do {
    codigo = "RDD-" + Math.random().toString(36).substring(2, 8).toUpperCase();
  } while (db.prepare("SELECT 1 FROM reservas WHERE codigo = ?").get(codigo));
  return codigo;
}

function capacidadeReservas(data) {
  const row = db.prepare(`
    SELECT COALESCE(SUM(pessoas),0) AS total
    FROM reservas
    WHERE data = ? AND status IN ('Pendente','Confirmada')
  `).get(data);
  return row.total;
}

app.get("/api/reservas", (req, res) => {
  const { data, status, busca } = req.query;
  let sql = "SELECT * FROM reservas WHERE 1=1";
  const params = [];

  if (data) { sql += " AND data = ?"; params.push(data); }
  if (status) { sql += " AND status = ?"; params.push(status); }
  if (busca) {
    sql += " AND (nome LIKE ? OR telefone LIKE ? OR codigo LIKE ?)";
    const q = `%${busca}%`;
    params.push(q, q, q);
  }

  sql += " ORDER BY data ASC, horario ASC, id DESC";
  res.json(db.prepare(sql).all(...params));
});

app.get("/api/reservas/:codigo", (req, res) => {
  const reserva = db.prepare("SELECT * FROM reservas WHERE codigo = ?").get(req.params.codigo.toUpperCase());
  if (!reserva) return res.status(404).json({ erro: "Reserva não encontrada." });
  res.json(reserva);
});

app.post("/api/reservas", (req, res) => {
  const { nome, telefone, email, data, horario, pessoas, observacoes = "" } = req.body;

  if (!nome || !telefone || !email || !data || !horario || !pessoas) {
    return res.status(400).json({ erro: "Preencha todos os campos obrigatórios." });
  }

  const qtd = Number(pessoas);
  if (!Number.isInteger(qtd) || qtd < 1 || qtd > 30) {
    return res.status(400).json({ erro: "Cada reserva pode ter no máximo 30 pessoas." });
  }

  const agora = new Date();
  const dataReserva = new Date(`${data}T${horario}:00`);
  if (Number.isNaN(dataReserva.getTime()) || dataReserva <= agora) {
    return res.status(400).json({ erro: "Escolha uma data e horário futuros." });
  }

  if (horario < "19:00" || horario > "23:00") {
    return res.status(400).json({ erro: "O horário de reservas deve começar às 19:00." });
  }

  const total = capacidadeReservas(data);
  if (total + qtd > 48) {
    return res.status(400).json({
      erro: `Não há lugares suficientes para esta data. Limite de reservas: 48 pessoas. Já reservadas: ${total}.`
    });
  }

  const codigo = codigoReserva();
  const criado = new Date().toISOString();

  db.prepare(`
    INSERT INTO reservas
    (codigo,nome,telefone,email,data,horario,pessoas,observacoes,status,criado_em)
    VALUES (?,?,?,?,?,?,?,?,?,?)
  `).run(codigo,nome,telefone,email,data,horario,qtd,observacoes,"Pendente",criado);

  res.status(201).json({
    mensagem: "Reserva criada com sucesso!",
    codigo,
    capacidadeUsada: total + qtd,
    capacidadeTotal: 48
  });
});

app.patch("/api/reservas/:codigo/status", (req, res) => {
  const { status } = req.body;
  const permitidos = ["Pendente","Confirmada","Cancelada","Concluída"];
  if (!permitidos.includes(status)) {
    return res.status(400).json({ erro: "Status inválido." });
  }

  const reserva = db.prepare("SELECT * FROM reservas WHERE codigo = ?").get(req.params.codigo.toUpperCase());
  if (!reserva) return res.status(404).json({ erro: "Reserva não encontrada." });

  db.prepare("UPDATE reservas SET status = ? WHERE codigo = ?").run(status, reserva.codigo);
  res.json({ mensagem: "Status atualizado." });
});

app.delete("/api/reservas/:codigo", (req, res) => {
  const reserva = db.prepare("SELECT * FROM reservas WHERE codigo = ?").get(req.params.codigo.toUpperCase());
  if (!reserva) return res.status(404).json({ erro: "Reserva não encontrada." });

  const dataHora = new Date(`${reserva.data}T${reserva.horario}:00`);
  const horas = (dataHora - new Date()) / 36e5;

  if (horas < 48) {
    return res.status(400).json({ erro: "Cancelamentos só são permitidos até 48 horas antes da reserva." });
  }

  db.prepare("UPDATE reservas SET status = 'Cancelada' WHERE codigo = ?").run(reserva.codigo);
  res.json({ mensagem: "Reserva cancelada." });
});

app.get("/api/dashboard", (req, res) => {
  const hoje = new Date().toISOString().slice(0,10);
  const total = db.prepare("SELECT COUNT(*) AS n FROM reservas").get().n;
  const pendentes = db.prepare("SELECT COUNT(*) AS n FROM reservas WHERE status='Pendente'").get().n;
  const confirmadas = db.prepare("SELECT COUNT(*) AS n FROM reservas WHERE status='Confirmada'").get().n;
  const pessoasHoje = db.prepare(`
    SELECT COALESCE(SUM(pessoas),0) AS n FROM reservas
    WHERE data=? AND status IN ('Pendente','Confirmada')
  `).get(hoje).n;
  const proximas = db.prepare(`
    SELECT * FROM reservas
    WHERE data >= ? AND status IN ('Pendente','Confirmada')
    ORDER BY data, horario LIMIT 5
  `).all(hoje);

  res.json({ total, pendentes, confirmadas, pessoasHoje, proximas, limite: 48 });
});

app.listen(PORT, () => {
  console.log(`🐉 Reino do Dragão rodando em http://localhost:${PORT}`);
});