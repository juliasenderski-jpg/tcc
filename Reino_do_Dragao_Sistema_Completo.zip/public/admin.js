let reservas=[];

function mostrar(id,btn){
  document.querySelectorAll(".view").forEach(x=>x.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
  document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
  if(id==="reservas") listar();
  if(id==="calendario") calendario();
}
async function carregar(){
  const r=await fetch("/api/dashboard"); const j=await r.json();
  sTotal.textContent=j.total;sPendentes.textContent=j.pendentes;sConfirmadas.textContent=j.confirmadas;sPessoas.textContent=`${j.pessoasHoje} / ${j.limite}`;
  proximas.innerHTML=j.proximas.length?j.proximas.map(x=>linha(x)).join(""):"<p class='muted'>Nenhuma reserva próxima.</p>";
}
function linha(x){
 return `<div class="reservation-row"><div><b>${x.horario}</b><div class="muted">${formatarData(x.data)}</div></div><div><b>${esc(x.nome)}</b><div class="muted">${esc(x.email)}</div></div><div>${x.pessoas} pessoa(s)</div><div class="status ${x.status}">${x.status}</div><div><button class="action" onclick="mudarStatus('${x.codigo}','Confirmada')">✓ Confirmar</button></div></div>`;
}
async function listar(){
 const p=new URLSearchParams();if(busca.value)p.set("busca",busca.value);if(fData.value)p.set("data",fData.value);if(fStatus.value)p.set("status",fStatus.value);
 const r=await fetch("/api/reservas?"+p);reservas=await r.json();
 tabela.innerHTML=reservas.length?reservas.map(x=>`<tr>
 <td><b>${x.codigo}</b></td><td>${esc(x.nome)}<br><span class="muted">${esc(x.telefone)}</span></td>
 <td>${formatarData(x.data)}</td><td>${x.horario}</td><td>${x.pessoas}</td>
 <td><span class="status ${x.status}">${x.status}</span></td>
 <td><div class="actions">${x.status==="Pendente"?`<button class="action" onclick="mudarStatus('${x.codigo}','Confirmada')">✓</button>`:""}${x.status==="Confirmada"?`<button class="action" onclick="mudarStatus('${x.codigo}','Concluída')">✓</button>`:""}<button class="action" onclick="mudarStatus('${x.codigo}','Cancelada')">✕</button></div></td>
 </tr>`).join(""):`<tr><td colspan="7">Nenhuma reserva encontrada.</td></tr>`;
}
async function mudarStatus(codigo,status){
 const r=await fetch("/api/reservas/"+codigo+"/status",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})});
 const j=await r.json();toast(j.mensagem||j.erro);listar();carregar();calendario();
}
async function calendario(){
 const d=calData.value || new Date().toISOString().slice(0,10);calData.value=d;
 const r=await fetch("/api/reservas?data="+d);const arr=await r.json();
 agenda.innerHTML=arr.length?arr.map(x=>`<div class="agenda-item"><div class="agenda-time">${x.horario}</div><div class="agenda-main"><div class="agenda-name">${esc(x.nome)} · ${x.pessoas} pessoa(s)</div><div class="muted">${esc(x.telefone)} · ${esc(x.codigo)}</div></div><span class="status ${x.status}">${x.status}</span><div class="agenda-actions">${x.status==="Pendente"?`<button class="action" onclick="mudarStatus('${x.codigo}','Confirmada')">Confirmar</button>`:""}<button class="action" onclick="mudarStatus('${x.codigo}','Cancelada')">Cancelar</button></div></div>`).join(""):"<div class='day-empty'>Nenhuma reserva para esta data.</div>";
}
function formatarData(s){const [a,m,d]=s.split("-");return `${d}/${m}/${a}`}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function toast(msg){const x=document.getElementById("toast");x.textContent=msg;x.style.display="block";setTimeout(()=>x.style.display="none",2500)}
calData.value=new Date().toISOString().slice(0,10);
carregar();listar();calendario();
