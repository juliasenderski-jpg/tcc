const form = document.getElementById("formReserva");
const dataInput = document.getElementById("data");
const horario = document.getElementById("horario");
const resultado = document.getElementById("resultado");

function hojeLocal(){
  const d = new Date();
  return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10);
}
dataInput.min = hojeLocal();

for(let h=19; h<=23; h++){
  for(let m of ["00","30"]){
    if(h===23 && m==="30") continue;
    const v=`${String(h).padStart(2,"0")}:${m}`;
    horario.innerHTML += `<option value="${v}">${v}</option>`;
  }
}

form.addEventListener("submit", async e=>{
  e.preventDefault();
  const body = Object.fromEntries(new FormData(form));
  body.pessoas = Number(body.pessoas);
  try{
    const r = await fetch("/api/reservas",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const j = await r.json();
    if(!r.ok) throw new Error(j.erro);
    resultado.className="result";
    resultado.innerHTML=`<h3>🔥 Reserva criada!</h3>
      <p>${j.mensagem}</p>
      <p>Seu código é <strong>${j.codigo}</strong>. Guarde este código para consultar sua reserva.</p>
      <p>O restaurante recebeu sua solicitação e poderá confirmá-la pelo painel.</p>`;
    form.reset();
    document.querySelector('[name="pessoas"]').value=2;
  }catch(err){
    resultado.className="result";
    resultado.style.background="#241013";
    resultado.innerHTML=`<strong>⚠️ ${err.message}</strong>`;
  }
});

async function consultar(){
  const codigo=document.getElementById("codigo").value.trim();
  const box=document.getElementById("consulta");
  if(!codigo){box.innerHTML="<p>Digite o código da reserva.</p>";return}
  const r=await fetch("/api/reservas/"+encodeURIComponent(codigo));
  const j=await r.json();
  if(!r.ok){box.innerHTML=`<div class="consult-result">⚠️ ${j.erro}</div>`;return}
  box.innerHTML=`<div class="consult-result">
    <b>${j.codigo}</b> · <span class="status ${j.status}">${j.status}</span>
    <p>${j.nome} · ${j.pessoas} pessoa(s)</p>
    <p>📅 ${formatarData(j.data)} · 🕐 ${j.horario}</p>
    <p>${j.observacoes || "Sem observações."}</p>
  </div>`;
}
function formatarData(s){const [a,m,d]=s.split("-");return `${d}/${m}/${a}`}
