const filtroData = document.getElementById("filtroData");
const tabela = document.getElementById("tabela");
const totalReservas = document.getElementById("totalReservas");
const totalPessoas = document.getElementById("totalPessoas");
const lugaresRestantes = document.getElementById("lugaresRestantes");

async function carregar() {
  const url = filtroData.value ? `/api/reservas?data=${filtroData.value}` : "/api/reservas";
  const r = await fetch(url);
  const reservas = await r.json();
  if (!r.ok) return;

  const confirmadas = reservas.filter(x => x.status === "CONFIRMADA");
  const pessoas = confirmadas.reduce((s,x) => s + Number(x.pessoas), 0);

  totalReservas.textContent = confirmadas.length;
  totalPessoas.textContent = pessoas;
  lugaresRestantes.textContent = Math.max(0, 48 - pessoas);

  tabela.innerHTML = reservas.length ? reservas.map(x => `
    <tr>
      <td><strong>${x.codigo}</strong></td>
      <td>${x.nome}</td>
      <td>${x.telefone}<br>${x.email}</td>
      <td>${new Date(x.data_reserva+"T12:00:00").toLocaleDateString("pt-BR")}</td>
      <td>${x.horario}</td>
      <td>${x.pessoas}</td>
      <td><span class="badge ${x.status === "CONFIRMADA" ? "confirmada" : "cancelada"}">${x.status}</span></td>
      <td>${x.status === "CONFIRMADA" ? `<button class="botao pequeno" onclick="cancelarAdmin('${x.codigo}')">Cancelar</button>` : "—"}</td>
    </tr>
  `).join("") : `<tr><td colspan="8">Nenhuma reserva encontrada.</td></tr>`;
}

async function cancelarAdmin(codigo) {
  if (!confirm(`Cancelar a reserva ${codigo}?`)) return;
  const r = await fetch(`/api/reservas/${codigo}`, { method:"DELETE" });
  const d = await r.json();
  alert(d.mensagem || d.erro);
  carregar();
}

document.getElementById("atualizar").addEventListener("click", carregar);
filtroData.addEventListener("change", carregar);
carregar();
