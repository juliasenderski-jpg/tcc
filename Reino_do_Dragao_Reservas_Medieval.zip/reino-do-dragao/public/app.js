const form = document.getElementById("reservaForm");
const data = document.getElementById("data");
const disponibilidade = document.getElementById("disponibilidade");
const mensagem = document.getElementById("mensagem");
const pessoas = document.getElementById("pessoas");
const codigoBusca = document.getElementById("codigoBusca");
const consulta = document.getElementById("consulta");

const hoje = new Date();
const yyyy = hoje.getFullYear();
const mm = String(hoje.getMonth()+1).padStart(2,"0");
const dd = String(hoje.getDate()).padStart(2,"0");
data.min = `${yyyy}-${mm}-${dd}`;

function formatarData(d) {
  return new Date(d + "T12:00:00").toLocaleDateString("pt-BR");
}

async function atualizarDisponibilidade() {
  if (!data.value) return;
  const r = await fetch(`/api/disponibilidade?data=${data.value}`);
  const d = await r.json();
  if (!r.ok) {
    disponibilidade.textContent = d.erro || "Erro.";
    return;
  }
  disponibilidade.innerHTML = `🏰 <strong>${d.disponiveis} lugares</strong> disponíveis para reservas em ${formatarData(d.data)} às ${d.horario}. (Limite de reservas: ${d.capacidadeReservas} pessoas)`;
  pessoas.max = Math.min(30, d.disponiveis);
}

data.addEventListener("change", atualizarDisponibilidade);

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  mensagem.innerHTML = "";
  const body = Object.fromEntries(new FormData(form).entries());
  body.pessoas = Number(body.pessoas);

  const r = await fetch("/api/reservas", {
    method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)
  });
  const d = await r.json();

  if (!r.ok) {
    mensagem.innerHTML = `<div class="mensagem-erro">⚠ ${d.erro}</div>`;
    return;
  }

  mensagem.innerHTML = `<div class="mensagem-sucesso">
    <strong>🐉 Reserva confirmada!</strong><br><br>
    Código: <strong>${d.codigo}</strong><br>
    ${d.nome} — ${d.pessoas} pessoa(s)<br>
    ${formatarData(d.data)} às ${d.horario}<br><br>
    Guarde este código para consultar ou cancelar sua reserva.
  </div>`;
  form.reset();
  pessoas.value = 2;
  data.min = `${yyyy}-${mm}-${dd}`;
  disponibilidade.textContent = "Reserva registrada no banco de dados.";
});

document.getElementById("buscarBtn").addEventListener("click", async () => {
  const codigo = codigoBusca.value.trim();
  if (!codigo) return;
  const r = await fetch(`/api/reservas/${encodeURIComponent(codigo)}`);
  const d = await r.json();
  if (!r.ok) {
    consulta.innerHTML = `<div class="mensagem-erro">${d.erro}</div>`;
    return;
  }

  consulta.innerHTML = `
    <div class="info">
      <strong>${d.nome}</strong><br>
      Código: ${d.codigo}<br>
      Data: ${formatarData(d.data_reserva)} às ${d.horario}<br>
      Pessoas: ${d.pessoas}<br>
      Status: <strong>${d.status}</strong>
      ${d.status === "CONFIRMADA" ? `<br><br><button class="botao pequeno" onclick="cancelar('${d.codigo}')">Cancelar reserva</button>` : ""}
    </div>`;
});

async function cancelar(codigo) {
  if (!confirm("Deseja realmente cancelar esta reserva?")) return;
  const r = await fetch(`/api/reservas/${codigo}`, { method:"DELETE" });
  const d = await r.json();
  consulta.innerHTML = `<div class="${r.ok ? "mensagem-sucesso" : "mensagem-erro"}">${d.mensagem || d.erro}</div>`;
}
