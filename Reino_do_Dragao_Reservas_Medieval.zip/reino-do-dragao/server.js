const express = require("express");
const path = require("path");
const { initDb, createReservation, listReservations, cancelReservation, getAvailability } = require("./db");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function isValidDate(date) {
  return /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(new Date(date + "T12:00:00").getTime());
}

app.get("/api/disponibilidade", async (req, res) => {
  try {
    const date = req.query.data;
    if (!isValidDate(date)) return res.status(400).json({ erro: "Data inválida." });
    const result = await getAvailability(date);
    res.json(result);
  } catch (e) {
    res.status(500).json({ erro: "Erro ao consultar disponibilidade." });
  }
});

app.post("/api/reservas", async (req, res) => {
  try {
    const result = await createReservation(req.body);
    res.status(201).json(result);
  } catch (e) {
    res.status(400).json({ erro: e.message });
  }
});

app.get("/api/reservas", async (req, res) => {
  try {
    const result = await listReservations(req.query.data || "");
    res.json(result);
  } catch (e) {
    res.status(500).json({ erro: "Erro ao carregar reservas." });
  }
});

app.delete("/api/reservas/:codigo", async (req, res) => {
  try {
    const result = await cancelReservation(req.params.codigo);
    res.json(result);
  } catch (e) {
    res.status(400).json({ erro: e.message });
  }
});

app.get("/api/reservas/:codigo", async (req, res) => {
  try {
    const all = await listReservations("");
    const item = all.find(r => r.codigo === req.params.codigo.toUpperCase());
    if (!item) return res.status(404).json({ erro: "Reserva não encontrada." });
    res.json(item);
  } catch (e) {
    res.status(500).json({ erro: "Erro ao consultar reserva." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

initDb().then(() => {
  app.listen(PORT, () => console.log(`Reino do Dragão rodando em http://localhost:${PORT}`));
}).catch(err => {
  console.error(err);
  process.exit(1);
});
