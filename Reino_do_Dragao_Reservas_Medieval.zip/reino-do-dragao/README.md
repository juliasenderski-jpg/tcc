# Reino do Dragão — Sistema de Reservas

Sistema completo, simples e funcional para um restaurante medieval.

## Regras implementadas

- Restaurante: **Reino do Dragão**
- Atendimento/reservas: **19:00**
- Capacidade física do salão: **120 pessoas**
- Apenas **40%** é liberado para reservas = **48 pessoas por data**
- Máximo de **30 pessoas por reserva**
- Reservas ficam armazenadas em **SQLite**
- Consulta de reserva por código
- Cancelamento pelo cliente até **48 horas antes**
- Painel do restaurante para visualizar e cancelar reservas
- Controle automático da capacidade por data
- Status CONFIRMADA/CANCELADA

## Como executar no VS Code

1. Instale o Node.js.
2. Abra esta pasta no VS Code.
3. Abra o terminal na pasta.
4. Execute:

```bash
npm install
npm start
```

5. Acesse:
   - Cliente: http://localhost:3000
   - Restaurante: http://localhost:3000/admin.html

O arquivo `reino_dragao.db` será criado automaticamente na primeira execução.

## Estrutura

- `server.js` — servidor Express e rotas da API
- `db.js` — banco SQLite e regras de negócio
- `public/index.html` — página do cliente
- `public/admin.html` — painel do restaurante
- `public/styles.css` — visual medieval
- `public/app.js` — funções da página do cliente
- `public/admin.js` — funções do painel
- `package.json` — dependências
