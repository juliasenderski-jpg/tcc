const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const crypto = require("crypto");

const db = new sqlite3.Database(path.join(__dirname, "reino_dragao.db"));

const CAPACIDADE_SALAO = 120;
const LIMITE_RESERVAS = Math.floor(CAPACIDADE_SALAO * 0.40); // 48 lugares
const MAX_PESSOAS_RESERVA = 30;
const HORA_RESERVA = "19:00";

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows));
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
  });
}

function initDb() {
  return run(`
    CREATE TABLE IF NOT EXISTS reservas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo TEXT UNIQUE NOT NULL,
      nome TEXT NOT NULL,
      telefone TEXT NOT NULL,
      email TEXT NOT NULL,
      pessoas INTEGER NOT NULL,
      data_reserva TEXT NOT NULL,
      horario TEXT NOT NULL DEFAULT '19:00',
      observacoes TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'CONFIRMADA',
      criada_em TEXT NOT NULL
    )
  `);
}

function normalizeDate(date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("Informe uma data válida.");
  return date;
}

function makeCode() {
  return "DRG-" + crypto.randomBytes(3).toString("hex").toUpperCase();
}

async function getAvailability(date) {
  date = normalizeDate(date);
  const row = await get(
    `SELECT COALESCE(SUM(pessoas), 0) AS ocupadas
     FROM reservas WHERE data_reserva = ? AND status = 'CONFIRMADA'`,
    [date]
  );
  const ocupadas = Number(row.ocupadas || 0);
  return {
    data: date,
    horario: HORA_RESERVA,
    capacidadeTotal: CAPACIDADE_SALAO,
    percentualLiberado: 40,
    capacidadeReservas: LIMITE_RESERVAS,
    ocupadas,
    disponiveis: Math.max(0, LIMITE_RESERVAS - ocupadas)
  };
}

async function createReservation(data) {
  const nome = String(data.nome || "").trim();
  const telefone = String(data.telefone || "").trim();
  const email = String(data.email || "").trim();
  const pessoas = Number(data.pessoas);
  const dataReserva = normalizeDate(data.data);
  const observacoes = String(data.observacoes || "").trim();

  if (!nome || nome.length < 2) throw new Error("Informe o nome do responsável.");
  if (!telefone) throw new Error("Informe o telefone.");
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Informe um e-mail válido.");
  if (!Number.isInteger(pessoas) || pessoas < 1 || pessoas > MAX_PESSOAS_RESERVA)
    throw new Error("A reserva deve ter entre 1 e 30 pessoas.");

  const hoje = new Date();
  const alvo = new Date(dataReserva + "T19:00:00");
  if (alvo <= hoje) throw new Error("Escolha uma data futura.");

  const disponibilidade = await getAvailability(dataReserva);
  if (pessoas > disponibilidade.disponiveis)
    throw new Error(`Não há lugares suficientes para esta data. Restam ${disponibilidade.disponiveis} lugares para reservas.`);

  let codigo = makeCode();
  while (await get("SELECT id FROM reservas WHERE codigo = ?", [codigo])) codigo = makeCode();

  await run(
    `INSERT INTO reservas
      (codigo, nome, telefone, email, pessoas, data_reserva, horario, observacoes, status, criada_em)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMADA', ?)`,
    [codigo, nome, telefone, email, pessoas, dataReserva, HORA_RESERVA, observacoes, "datetime('now')"]
  );

  return {
    mensagem: "Reserva confirmada!",
    codigo,
    nome,
    pessoas,
    data: dataReserva,
    horario: HORA_RESERVA,
    podeCancelarAte: new Date(alvo.getTime() - 48 * 60 * 60 * 1000).toISOString()
  };
}

async function listReservations(date = "") {
  if (date) {
    return all(
      `SELECT * FROM reservas WHERE data_reserva = ? ORDER BY horario, id`,
      [date]
    );
  }
  return all(`SELECT * FROM reservas ORDER BY data_reserva, horario, id`);
}

async function cancelReservation(codigo) {
  const reserva = await get(`SELECT * FROM reservas WHERE codigo = ?`, [codigo.toUpperCase()]);
  if (!reserva) throw new Error("Reserva não encontrada.");
  if (reserva.status === "CANCELADA") throw new Error("Esta reserva já foi cancelada.");

  const inicio = new Date(reserva.data_reserva + "T19:00:00");
  const limite = new Date(inicio.getTime() - 48 * 60 * 60 * 1000);
  if (new Date() > limite)
    throw new Error("O prazo de cancelamento de 48 horas antes da reserva já terminou.");

  await run(`UPDATE reservas SET status = 'CANCELADA' WHERE codigo = ?`, [codigo.toUpperCase()]);
  return { mensagem: "Reserva cancelada com sucesso." };
}

module.exports = {
  initDb,
  createReservation,
  listReservations,
  cancelReservation,
  getAvailability
};
